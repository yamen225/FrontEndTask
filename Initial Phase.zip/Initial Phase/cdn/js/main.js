$(document).ready(() => {
	$("#nav-bar").load("nav-bar.html");
    $("#header1").load("header.html");
    $("#footer").load("footer.html");
    
});

